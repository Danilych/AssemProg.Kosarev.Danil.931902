#pragma once

static class AssemblerInsert
{

    /*
    1. ����������� ����� ��������� ������������ �������.
        1. ������� �������������� ��������.
        1. ��������.                                        +
        2. ���������.                                       +
        3. ���������.                                       +
        4. �������.                                         +
    2. �������� ���������.                                  +
    3. ���������� ��������.                                 +
    not, and, or , xor
    4. ���������� �� �������                                +
    5. �������� ������                                      +
    6. ����������� ����� ������� ����� ��������� ������ - ������� � �������� ��� - �� ��������. void (func, n); +
    */
    //1
public:
    static int Add(int a, int b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            add eax, b
            mov c, eax
        }
        return c;
    }

    static int Substract(int a, int b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            sub eax, b
            mov c, eax
        }
        return c;
    }

    static unsigned _int64 Multiply(unsigned int a, unsigned int b)
    {
        unsigned int r1;
        unsigned int r2;

        unsigned _int64 result = 0;

        _asm
        {
            mov eax, b
            mul a
            mov r1, edx
            mov r2, eax
        }

        for (int i = 0; i < 64; i++)
        {
            if (i < 32) //small
            {
                if (r2 & (1 << i)) result |= 1ULL << i;

            }
            else //big
            {
                if (r1 & (1 << (i - 32))) result |= 1ULL << i;
            }
        }

        return result;
    }

    static unsigned int Divide(unsigned _int64 a, unsigned int b)
    {
        unsigned int a1 = 0; //small
        unsigned int a2 = 0; //big

        for (int i = 0; i < 64; i++)
        {
            if (i < 32)
            {
                if (a & (1ULL << i)) a1 |= 1UL << i;

            }
            else
            {
                if (a & (1ULL << i)) a2 |= 1UL << (i - 32);
            }
        }

        _asm
        {
            mov eax, a1
            mov edx, a2
            div b
            mov a1, edx; �������
            mov a2, eax; �������
        }

        return a2;
    }
    //2
    static bool Eq(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov eax, a
            cmp eax, b
            je R
            jne S
            R : mov c, 1
            S :
        }
        return c;
    }

    static bool Uneq(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov eax, a
            cmp eax, b
            je R
            jne S
            S : mov c, 1
            R :
        }
        return c;
    }

    static bool Greater(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov bl, 1
            mov eax, a
            cmp eax, b
            jg E
            ja E
            mov bl, 0
            E : mov c, bl
        }
        return c;
    }

    static bool GreaterEq(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov bl, 1
            mov eax, a
            cmp eax, b
            jge E
            jae E
            mov bl, 0
            E : mov c, bl
        }
        return c;
    }

    static bool Less(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov bl, 1
            mov eax, a
            cmp eax, b
            jl E
            jb E
            mov bl, 0
            E : mov c, bl
        }
        return c;
    }

    static bool LessEq(int a, int b)
    {
        bool c = false;

        _asm
        {
            mov bl, 1
            mov eax, a
            cmp eax, b
            jle E
            jbe E
            mov bl, 0
            E : mov c, bl
        }
        return c;
    }
    //3
    static bool Not(bool a)
    {
        bool b = a;

        _asm
        {
            not b
        }

        if (b & (1 << 0)) return true;
        else return false;
    }

    static bool And(bool a, bool b)
    {
        bool c = a;

        _asm
        {
            mov al, b
            and c, al
        }

        if (c & (1 << 0)) return true;
        else return false;
    }

    static bool Or(bool a, bool b)
    {
        bool c = a;

        _asm
        {
            mov al, b
            or c, al
        }

        if (c & (1 << 0)) return true;
        else return false;
    }

    static bool Xor(bool a, bool b)
    {
        bool c = a;

        _asm
        {
            mov al, b
            xor c, al
        }

        if (c & (1 << 0)) return true;
        else return false;
    }
    //4
    static int ArrayIndex(int* arr, int in)
    {
        int a = 0;
        _asm
        {
            mov ebx, in
            mov eax, arr
            mov ebx, [eax + 4 * ebx]
            mov a, ebx
        }
        return a;
    }
    //5
    static int LShiftLeft(int a, unsigned char b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            mov cl, b
            shl eax, cl
            mov c, eax
        }
        return c;
    }

    static int LShiftRight(int a, unsigned char b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            mov cl, b
            shr eax, cl
            mov c, eax
        }
        return c;
    }

    static int CShiftLeft(int a, unsigned char b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            mov cl, b
            rol eax, cl
            mov c, eax
        }
        return c;
    }

    static int CShiftRight(int a, unsigned char b)
    {
        int c = 0;
        _asm
        {
            mov eax, a
            mov cl, b
            ror eax, cl
            mov c, eax
        }
        return c;
    }
    //6
    static void Repeat(void (*func)(int, int), int i)
    {
        int c = 0;
        _asm
        {
            START :

            push i
            push c
            call func
            add esp, 8

            add c, 1
            mov eax, i
            cmp c, eax

            je END
            jne START

            END :
        }
    }

};